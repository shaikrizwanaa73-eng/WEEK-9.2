# JDBC Insert Data Lab (2.1)

## Aim
Connect to MySQL using JDBC, create the `users` table if it does not exist,
and insert two user records with `PreparedStatement`.

## Requirements
- Java JDK installed
- MySQL Server running
- MySQL Connector/J JDBC driver
- A MySQL database named `mydatabase`

## Configure your credentials
Open `src/JDBCInsert.java` and replace `your_password` with your MySQL password.
If your MySQL username is not `root`, update `USERNAME` as well.

The program creates the `users` table with `id`, `name`, and `email` columns.
It uses an auto-incrementing ID, so each run inserts two additional rows.

## Compile and run
Ensure the MySQL Connector/J JAR is available. If it is named
`mysql-connector-j.jar` and placed in this project folder:

### macOS / Linux
```bash
javac -cp ".:mysql-connector-j.jar" -d out src/JDBCInsert.java
java -cp "out:mysql-connector-j.jar" JDBCInsert
```

### Windows
```bat
javac -cp ".;mysql-connector-j.jar" -d out src/JDBCInsert.java
java -cp "out;mysql-connector-j.jar" JDBCInsert
```

If the database does not exist yet, create it in MySQL first:
```sql
CREATE DATABASE IF NOT EXISTS mydatabase;
```

## Expected output
```text
Data inserted successfully.
```

The program uses `PreparedStatement` and try-with-resources to insert records
and automatically close JDBC resources.
